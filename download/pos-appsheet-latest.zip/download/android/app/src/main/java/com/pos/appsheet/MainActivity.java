package com.pos.appsheet;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
