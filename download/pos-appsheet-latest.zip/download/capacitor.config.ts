import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.pos.appsheet',
  appName: 'POS AppSheet',
  webDir: 'out'
};

export default config;
